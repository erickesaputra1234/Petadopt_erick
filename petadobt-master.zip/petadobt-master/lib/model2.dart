class modelfilter {
  String? title;
  String? img;

  modelfilter({this.img, this.title});
}
