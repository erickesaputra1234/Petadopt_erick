class modelBinatang {
  String? img;
  String? nama;
  String? umur;
  String? Jenis;
  String? Kelamin;
  int? Timbangan;
  String? Warna;
  String? jarak;
  modelBinatang({this.Jenis, this.img, this.nama, this.umur,this.Kelamin,this.Timbangan,this.Warna,this.jarak});
}
