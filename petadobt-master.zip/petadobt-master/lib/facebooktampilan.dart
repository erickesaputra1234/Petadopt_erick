import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class facebooktampilan extends StatelessWidget {
  const facebooktampilan({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Image.asset("assets/facebootampilan.png",scale: 0.1,height: 1000,),
    );
  }
}